public class Main {
    public static void main(String[] args) {

        class Persona {
            int edad;
            String nombre;
            int teléfono;
        }

        class Cliente extends Persona {
            int crédito;
        }

        Cliente cliente1 = new Cliente ();
        cliente1.edad = 18;
        cliente1.nombre = "Pedro";
        cliente1.teléfono = 678678678;
        cliente1.crédito = 30000;

        System.out.println(cliente1.edad + " " + cliente1.nombre + " " + cliente1.teléfono + " " + cliente1.crédito);

        class Trabajador extends Persona {
            int salario;
        }

        Trabajador trabajador1 = new Trabajador();
        trabajador1.edad = 18;
        trabajador1.nombre = "Pedro";
        trabajador1.teléfono = 678678678;
        trabajador1.salario = 1750;

        System.out.println(trabajador1.edad + " " + trabajador1.nombre + " " + trabajador1.teléfono + " " + trabajador1.salario);

    }
}